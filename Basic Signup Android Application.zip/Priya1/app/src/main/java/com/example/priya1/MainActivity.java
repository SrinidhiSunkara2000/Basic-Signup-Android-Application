package com.example.priya1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.SeekBar;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
Button rollButton1;
TextView textView1,resultsTextView1;
SeekBar seekBar1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rollButton1=(Button)findViewById(R.id.rollButton);
        textView1=(TextView)findViewById(R.id.textView);
        resultsTextView1=(TextView)findViewById(R.id.resultsTextView);
        seekBar1=(SeekBar)findViewById(R.id.seekBar);
        rollButton1.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view.getId()==R.id.rollButton){
            textView1.setText("roll Button is clicked");
        }
    }

}
